package matices;

import java.util.Scanner;

public class Matices {

    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);

        Matriz matriz = new Matriz();
        
        System.out.print("Digite la cantidad de filas de la matriz: ");
        int filas = sc.nextInt();
        
        System.out.print("Digite la cantidad de columnas de la matriz: ");
        int cols = sc.nextInt();

        matriz.set(filas, cols);
        
        matriz.llenadoAcendente();
        matriz.imprimirMatriz("***LLENADO ACENDENTE***");
        /*

        
        matriz.llenadoManual();
        matriz.imprimirMatriz("***LLENADO MANUAL***");



/*
        // Vector unidimensional
        int[] v = {4, 5, -2, 7, 15};

        for (int i = 0; i < v.length; i++) 
        {
            System.out.print(v[i] + " ");
        }
        System.out.println("");

        // Llenado por código de matriz bidimensional
        int[][] u = 
        {
            {2, 4},
            {-1, 0},
            {-5, 7}
        };

        System.out.println("LLENADO POR CODIGO");
        for (int fila = 0; fila < 3; fila++) 
        {
            for (int col = 0; col < 2; col++) 
            {
                System.out.print(m[fila][col] + "\t");
            }
            System.out.println();
        }

        // Scanner disponible por si se desea usar después
        Scanner sc = new Scanner(System.in);

        // Llenado manual
        for (int fila = 0; fila < 3; fila++) 
        {
            for (int col = 0; col < 2; col++) 
            {
                System.out.print("Digite el m[" + fila + "][" + col + "] = ");
                m[fila][col] = sc.nextInt();
            }
        }

        System.out.println("\nLLENADO MANUAL");
        for (int fila = 0; fila < 3; fila++) 
        {
            for (int col = 0; col < 2; col++) 
            {
                System.out.print(m[fila][col] + "\t");
            }
            System.out.println();
        }

        // Llenado aleatorio
        int limInf = -10;
        int limSup = 10;

        //llenado aleatorio
        for (int fila = 0; fila < 3; fila++) 
        {
            for (int col = 0; col < 2; col++) 
            {
                m[fila][col] = (int) (Math.random() * (limSup - limInf) + limInf);
            }
        }

        System.out.println("LLENADO ALEATORIO");
        for (int fila = 0; fila < 3; fila++) 
        {
            for (int col = 0; col < 2; col++) 
            {
                System.out.print(m[fila][col] + "\t");
            }

            System.out.println("");
        }
*/
    }

}
