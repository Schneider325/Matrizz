package matices;
import java.util.Scanner;

public class Matriz 
{
    private int mFilas;
    private int nCols;
    private int[][] m;

    public Matriz() 
    {
        mFilas = 0;
        nCols = 0;
        m = null;
    }

    public Matriz(int filas, int cols) 
    {
        mFilas = (filas > 0) ? filas : 0;
        nCols = (cols > 0) ? cols : 0;
        m = (mFilas > 0 && nCols > 0) ? new int[mFilas][nCols] : null;
    }

    public void set(int filas, int cols) 
    {
        mFilas = (filas > 0) ? filas : 0;
        nCols = (cols > 0) ? cols : 0;
        m = (mFilas > 0 && nCols > 0) ? new int[mFilas][nCols] : null;
    }

    public void llenadoManual() 
    {
        Scanner sc = new Scanner(System.in);
        for (int fila = 0; fila < mFilas; fila++) 
            for (int col = 0; col < nCols; col++) 
            {
                System.out.print("Digite el m[" + fila + "][" + col + "] = ");
                m[fila][col] = sc.nextInt();
            }   
    }
    
    private int aleatorioEntre(int limInf, int limSup)
    {
        return (int)(Math.random() * (limSup - limInf)) + limInf;
    }
    
    public void llenadoAcendente() 
    {
        int z = 1;
        for (int fila = 0; fila < mFilas; fila++) 
            for (int col = 0; col < nCols; col++) 
                m[fila][col] = z++;
    }

    public void imprimirMatriz(String mensaje) 
    {
        System.out.println(mensaje);
        for (int fila = 0; fila < mFilas; fila++) 
        {
            for (int col = 0; col < nCols; col++) 
                System.out.print(m[fila][col] + "\t");
            System.out.println();
        }
    }
    
    
}